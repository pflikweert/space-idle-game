# VOID DRIFTER — Player Ship MVP Assets

Source: Luma 6-state player ship asset sheet.

Files:
- player_ship_idle.png — default in-game player sprite
- player_ship_bank_left.png — optional movement/banking left
- player_ship_bank_right.png — optional movement/banking right
- player_ship_boost.png — optional boost/thrust state
- player_ship_damaged.png — optional low-HP/damage state
- player_ship_icon.png — UI icon / upgrade menu / life counter

Also included:
- /256 versions — centered 256×256 PNGs for quick MVP/web use.

Recommended MVP use:
1. Start with player_ship_idle.png only.
2. Use player_ship_bank_left/right when player moves horizontally.
3. Use player_ship_boost for acceleration/level-up/temporary speed upgrade.
4. Use player_ship_damaged below 30% HP.
